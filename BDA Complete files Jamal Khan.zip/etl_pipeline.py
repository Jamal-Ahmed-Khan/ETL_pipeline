
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import requests
import csv
import sqlite3
from datetime import datetime
import os
import load_to_db
import matplotlib.pyplot as plt


def fetch_forecast(city):
    # Use the forecast endpoint (5 day / 3 hour forecast)
    print("fetching Data from openWeather API")
    API_KEY = 'cdc23585344f54d1d00caef6a3cffb60'  # Replace with your real API key
    url = f'http://api.openweathermap.org/data/2.5/forecast?q={city}&appid={API_KEY}&units=metric'
    response = requests.get(url)

    if response.status_code != 200:
        raise Exception(f"Error fetching weather data: {response.status_code}")

    data = response.json()

    # Check if the response contains an error code
    if data.get("cod") != "200":
        error_message = data.get("message", "Unknown error")
        raise Exception(f"Error fetching weather data: {error_message}")

    # Extract forecast entries with temperature, humidity, and wind speed
    forecast_entries = []
    for entry in data.get('list', []):
        try:
            # Convert Unix timestamp to human-readable format
            timestamp = datetime.utcfromtimestamp(entry['dt']).strftime('%Y-%m-%d %H:%M:%S')
            temperature = entry['main']['temp']
            humidity = entry['main']['humidity']
            wind_speed = entry['wind']['speed']

            forecast_entries.append({
                'timestamp': timestamp,
                'temperature': temperature,
                'humidity': humidity,
                'wind_speed': wind_speed,
                'city': city
            })
        except KeyError as e:
            print(f"Key error {e} in entry: {entry}")

    return forecast_entries


def create_weather_csv(data, filename):
      # Ensure the directory exists
      os.makedirs(os.path.dirname(filename), exist_ok=True)

      # Open the file in write mode
      with open(filename, mode='w', newline='') as file:
          writer = csv.writer(file)

          # Write the header with an additional column for Fahrenheit
          writer.writerow(['timestamp', 'temperature_celsius', 'temperature_fahrenheit', 'humidity', 'wind_speed'])

          # Write the data with both Celsius and Fahrenheit
          for entry in data:
              temperature_fahrenheit = (entry['temperature'] * 9/5) + 32  # Convert to Fahrenheit
              writer.writerow([entry['timestamp'], entry['temperature'],
                               temperature_fahrenheit, entry['humidity'], entry['wind_speed'],])

      print(f"Data saved as {filename}.")

def getGoogleSheetsData():
    # Replace with your actual spreadsheet ID and sheet ID (GID)
    spreadsheet_id = "1DIXLTQfPB76206gklGInqhRzg5KW_uHbGXmwkBVg56k"
    sheet_id = "1229579343"  # Sheet ID (GID)

    # Construct the export URL for CSV format
    # url = f"https://docs.google.com/spreadsheets/d/{spreadsheet_id}/export?format=csv&gid={sheet_id}"
    url = "https://docs.google.com/spreadsheets/d/1W0n624gcU4A589YJWi_4YhyDNAFjeHqYdoUU-nLMbQk/export?format=csv&gid=1753712753#gid=1753712753"

    # Send a GET request to the URL
    response = requests.get(url)

    # Check if the request was successful (status code 200)
    if response.status_code == 200:
        # Save to a local file
        print(response.content)
        with open('ETL_Pipeline_jamal_DS-056/data/google_sheet_sample.csv', 'wb') as f:
            f.write(response.content)
    else:
        print(f"Failed to download the CSV file. Status code: {response.status_code}")


def refreshData():
    weather_data = fetch_forecast('London')
    create_weather_csv(weather_data, "ETL_Pipeline_jamal_DS-056/data/sample_data.csv")
    getGoogleSheetsData()



def extractData():
    # 1. Load Data from JSON
    json_data = pd.read_json('ETL_Pipeline_jamal_DS-056/data/weather_data.json')

    # 2. Load Data from CSVs
    csv_data1 = pd.read_csv('ETL_Pipeline_jamal_DS-056/data/google_sheet_sample.csv')
    csv_data2 = pd.read_csv('ETL_Pipeline_jamal_DS-056/data/sample_data.csv')

    # 3. Load Data from SQLite Database
    # Connect to SQLite database (replace with your actual DB path and table)
    conn = sqlite3.connect('ETL_Pipeline_jamal_DS-056/data/weather_data.db')
    sqlite_data = pd.read_sql('SELECT timestamp, temperature_celsius, temperature_fahrenheit FROM weather_data', conn)
    conn.close()

    # 4. Combine the Data
    # Assuming each dataset has 'timestamp', 'temperature_celsius', 'temperature_fahrenheit'
    combined_data = pd.concat([json_data, csv_data1, csv_data2, sqlite_data], ignore_index=True)

    # 5. Optional: Convert timestamp column to datetime (if needed)
    combined_data['timestamp'] = pd.to_datetime(combined_data['timestamp'])

    # 6. Optional: Sort by timestamp
    combined_data.sort_values(by='timestamp', inplace=True)
    combined_data.reset_index(drop=True, inplace=True)

    # 7. Print the final combined DataFrame
    return combined_data


def remove_outliers_and_impute_mean(df, col):

    # For a given DataFrame column, detects outliers using the IQR method,
    # replaces them with NaN, and then fills all NaN values with the column mean.

    # Calculate Q1, Q3 and IQR using non-missing values
    Q1 = df[col].quantile(0.25)
    Q3 = df[col].quantile(0.75)
    IQR = Q3 - Q1

    # Define acceptable range based on the IQR rule
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR

    # Debug print statements (optional)
    print(f"{col} - Q1: {Q1:.2f}, Q3: {Q3:.2f}, IQR: {IQR:.2f}")
    print(f"{col} - Lower bound: {lower_bound:.2f}, Upper bound: {upper_bound:.2f}")

    # Replace outliers (non-missing) with NaN. Missing values remain NaN.
    mask_outliers = ((df[col] < lower_bound) | (df[col] > upper_bound)) & (df[col].notna())
    df.loc[mask_outliers, col] = np.nan

    # After marking outliers as missing, compute the mean of the non-missing (non-outlier) values.
    mean_val = df[col].mean()
    print(f"{col} - Mean (computed from non-outliers): {mean_val:.2f}")

    # Fill missing values with the computed mean.
    df[col].fillna(mean_val, inplace=True)


def weatherImpactScore(df):
    df_norm = df.copy()
    df_norm['temperature_celsius'] = (df['temperature_celsius'] - df['temperature_celsius'].min()) / (df['temperature_celsius'].max() - df['temperature_celsius'].min())
    df_norm['humidity'] = (df['humidity'] - df['humidity'].min()) / (df['humidity'].max() - df['humidity'].min())
    df_norm['wind_speed'] = (df['wind_speed'] - df['wind_speed'].min()) / (df['wind_speed'].max() - df['wind_speed'].min())

    # Define weights (adjustable)
    temp_weight = 0.4
    humidity_weight = 0.3
    wind_weight = 0.3

    # Calculate weather impact score
    df['weather_impact'] = (
        temp_weight * df_norm['temperature_celsius'] +
        humidity_weight * df_norm['humidity'] +
        wind_weight * df_norm['wind_speed']) * 100  # scale to a 0–100 score


def cleanData(df):
    # Process each column separately.
    remove_outliers_and_impute_mean(df, 'temperature_celsius')
    remove_outliers_and_impute_mean(df, 'temperature_fahrenheit')
    remove_outliers_and_impute_mean(df, 'humidity')
    remove_outliers_and_impute_mean(df, 'wind_speed')


    weatherImpactScore(df)

    # Round all values in the DataFrame to 3 decimal places
    df = df.round(3)

    df.drop_duplicates(subset='timestamp', keep='last')
    df.to_json('ETL_Pipeline_jamal_DS-056/data/cleaned_data.json', orient='records')
    # df.to_csv('')
    return df


def calculate_and_plot_metrics():
    df = pd.read_json('ETL_Pipeline_jamal_DS-056/data/cleaned_data.json')

    # Calculate daily metrics from the given DataFrame and generate plots.

    # Expected columns in df:
    # - "temperature_fahrenheit"
    # - "temperature_celsius"
    # - "humidity"
    # - "wind_speed"
    # - "weather_impact"
    # - "timestamp" (datetime type or convertible)

    # Parameters:
    # df (pd.DataFrame): DataFrame containing the weather data.

    # Returns:
    # metrics (pd.DataFrame): A DataFrame with daily aggregated metrics.

    # Ensure that the timestamp column is in datetime format
    if not pd.api.types.is_datetime64_any_dtype(df['timestamp']):
        df['timestamp'] = pd.to_datetime(df['timestamp'])

    # Create a date column to group by day (if you want to ignore time)
    df['date'] = df['timestamp'].dt.date

    # Calculate daily metrics.
    # You can change the aggregation functions as needed.
    daily_metrics = df.groupby('date').agg({
        'temperature_fahrenheit': ['mean', 'min', 'max'],
        'temperature_celsius': ['mean', 'min', 'max'],
        'humidity': 'mean',
        'wind_speed': 'mean',
        'weather_impact': 'mean'
    })

    # Flatten the MultiIndex columns if necessary:
    daily_metrics.columns = ['_'.join(col).strip() for col in daily_metrics.columns.values]
    daily_metrics.reset_index(inplace=True)

    # Plotting the metrics
    fig, axs = plt.subplots(nrows=3, ncols=1, figsize=(12, 18))

    # Plot average temperatures (F and C)
    axs[0].plot(daily_metrics['date'], daily_metrics['temperature_fahrenheit_mean'], label='Avg Temp (°F)', marker='o')
    axs[0].plot(daily_metrics['date'], daily_metrics['temperature_celsius_mean'], label='Avg Temp (°C)', marker='o')
    axs[0].set_title('Daily Average Temperature')
    axs[0].set_xlabel('Date')
    axs[0].set_ylabel('Temperature')
    axs[0].legend()
    axs[0].grid(True)

    # Plot average humidity
    axs[1].plot(daily_metrics['date'], daily_metrics['humidity_mean'], label='Avg Humidity (%)', color='green', marker='o')
    axs[1].set_title('Daily Average Humidity')
    axs[1].set_xlabel('Date')
    axs[1].set_ylabel('Humidity (%)')
    axs[1].legend()
    axs[1].grid(True)

    # Plot average wind speed and weather impact
    axs[2].plot(daily_metrics['date'], daily_metrics['wind_speed_mean'], label='Avg Wind Speed', color='red', marker='o')
    axs[2].plot(daily_metrics['date'], daily_metrics['weather_impact_mean'], label='Avg Weather Impact', color='purple', marker='o')
    axs[2].set_title('Daily Average Wind Speed and Weather Impact')
    axs[2].set_xlabel('Date')
    axs[2].set_ylabel('Value')
    axs[2].legend()
    axs[2].grid(True)

    plt.tight_layout()
    plt.show()

    return daily_metrics




def main():

    ### Extract
    refreshData()
    combined_data = extractData()
    print("Combined data extracted successfully.")
    print(combined_data.head())
    ### Transform
    cleanData(combined_data) # data cleaning and saving as .json file
    print("Data cleaned and saved successfully.")
    daily_metrics = calculate_and_plot_metrics()
    print(daily_metrics)



if __name__ == "__main__":
    main()
